# ColorConnect (Web)

A web-based version of ColorConnect for 55+ communities. Color-coded “approachability” states help residents discover who’s open to a friendly chat and view lightweight profiles.

- **Green ✔** “Please say hi”
- **Yellow ●** “Small talk ok”
- **Blue ✚** “Looking for a buddy”
- **Red —** “Quiet time”

## Tech
- React 18 + Vite + TypeScript
- Zustand for state
- React Router for navigation
- Tailwind CSS for accessible UI
- React Hook Form + Zod for onboarding form
- **Mock Mode** (default) generates nearby neighbors
- **Web Bluetooth (optional)** lets users pair with *their own* wristband to set COLOR_STATE (browser must support Web Bluetooth; Chrome/Edge over HTTPS)

> Note: Passive BLE scanning for *other* devices isn’t supported in stable Web Bluetooth. The Nearby list is mock by default. For real deployments, combine Web Bluetooth (for *my* band control) with a backend (e.g., Supabase) that maps daily tokens to profiles and shares GREEN presence server-side.

## Dev Quick Start
```bash
npm install
npm run dev
```
Open http://localhost:5173

## Build
```bash
npm run build
npm run preview
```

## GitHub Pages Deploy (recommended)
1. Ensure your repo is named **ColorConnect** under your GitHub user (e.g., `github.com/BenHowerton/ColorConnect`).
2. Copy `.env.example` to `.env` and keep:
   ```env
   VITE_BASE=/ColorConnect/
   VITE_USE_MOCK=true
   ```
3. Commit and push to `main`. The provided workflow `.github/workflows/deploy.yml` will build and publish to **gh-pages** automatically via GitHub Pages.
4. In your repo settings → **Pages**, set **Source** to “GitHub Actions”. Your site will be available at:
   `https://<your-username>.github.io/ColorConnect/`

## Web Bluetooth (My Band)
- Click **Connect my band** on the Scan page to pair via Web Bluetooth.
- Your band must expose:
  - Service: `b59a0001-13f0-4c2a-b4ce-7d6fddc0aa01`
  - `COLOR_STATE` (uint8): `b59a0002-13f0-4c2a-b4ce-7d6fddc0aa01`
  - `USER_TOKEN` (16 bytes): `b59a0003-13f0-4c2a-b4ce-7d6fddc0aa01`
- After pairing, you can set your color from the Scan page.

> Web Bluetooth requires HTTPS and is best supported on Chrome/Edge (Desktop/Android). iOS Safari currently has limited support.

## Files
- `src/pages/` — `Onboarding`, `Scan`, `Profile`, `Settings`, `DirectorTools`, `Etiquette`
- `src/components/` — `ColorPicker`, `NearbyList`, `ProfileCard`
- `src/ble/webBle.ts` — Web Bluetooth helper for pairing and setting color on *your* band
- `src/data/mock.ts` — seed users + simulated nearby GREEN list
- `src/store.ts` — Zustand global state
- `src/types.ts` — shared types + UUIDs
- `.github/workflows/deploy.yml` — GitHub Pages Action (builds from `main` and deploys to Pages)

## Pilot Script (Director)
1. **Before event:** Ensure site is published to GitHub Pages; have a few bands ready for demo. Participants can use Mock Mode without hardware.
2. **Kickoff (2 min):** Explain color meanings; open `/etiquette` on a big screen.
3. **Green Hour (15–30 min):** Encourage folks to set GREEN and browse nearby list (mock) or connect their own band to set color.
4. **Wrap (3 min):** Gather feedback.

## License
MIT
