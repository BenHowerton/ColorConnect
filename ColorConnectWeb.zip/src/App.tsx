import React, { useEffect } from 'react'
import { BrowserRouter, Link, Route, Routes, Navigate, useLocation } from 'react-router-dom'
import Onboarding from './pages/Onboarding'
import Scan from './pages/Scan'
import Explore from './pages/Explore'
import Profile from './pages/Profile'
import Settings from './pages/Settings'
import DirectorTools from './pages/DirectorTools'
import Etiquette from './pages/Etiquette'
import { useStore } from './store'

function Tabs(){
  const loc = useLocation()
  const items = [
    { to: '/scan', label: 'Scan' },
    { to: '/explore', label: 'Explore' },
    { to: '/profile/me', label: 'My Profile' },
    { to: '/settings', label: 'Settings' },
  ]
  return (
    <div className="fixed bottom-0 left-0 right-0 border-t bg-white/90 backdrop-blur dark:bg-neutral-900/90">
      <div className="container">
        <div className="grid grid-cols-4 gap-2 py-3">
          {items.map(i => (
            <Link key={i.to} to={i.to} className={`text-center font-medium ${loc.pathname.startsWith(i.to) ? 'text-brand' : 'text-gray-600'}`}>
              {i.label}
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}

export default function App(){
  const me = useStore(s => s.me)

  return (
    <BrowserRouter basename={import.meta.env.VITE_BASE || '/'}>
      <Routes>
        <Route path="/" element={me?.displayName ? <Navigate to="/scan" /> : <Onboarding />} />
        <Route path="/scan" element={<><Scan /><Tabs/></>} />
        <Route path="/explore" element={<><Explore /><Tabs/></>} />
        <Route path="/profile/:name" element={<><Profile /><Tabs/></>} />
        <Route path="/settings" element={<><Settings /><Tabs/></>} />
        <Route path="/director" element={<DirectorTools />} />
        <Route path="/etiquette" element={<Etiquette />} />
      </Routes>
    </BrowserRouter>
  )
}
