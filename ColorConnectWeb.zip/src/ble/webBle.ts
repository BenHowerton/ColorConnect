import { ColorState, CHAR_COLOR_STATE, CHAR_USER_TOKEN, SERVICE_UUID } from '../types'

export type WebBand = {
  device: BluetoothDevice
  server: BluetoothRemoteGATTServer
  colorChar?: BluetoothRemoteGATTCharacteristic
  tokenChar?: BluetoothRemoteGATTCharacteristic
  userTokenHex?: string
}

function toHex(view: DataView) {
  let s = ''
  for (let i = 0; i < view.byteLength; i++) {
    const h = view.getUint8(i).toString(16).padStart(2,'0')
    s += h
  }
  return s
}

export async function connectBand(): Promise<WebBand> {
  if (!navigator.bluetooth) throw new Error('Web Bluetooth not supported in this browser. Try Chrome or Edge over HTTPS.')
  const device = await navigator.bluetooth.requestDevice({
    filters: [{ services: [SERVICE_UUID] }],
    optionalServices: [SERVICE_UUID]
  })
  const server = await device.gatt!.connect()
  const service = await server.getPrimaryService(SERVICE_UUID)
  const colorChar = await service.getCharacteristic(CHAR_COLOR_STATE)
  let tokenChar: BluetoothRemoteGATTCharacteristic | undefined
  try {
    tokenChar = await service.getCharacteristic(CHAR_USER_TOKEN)
  } catch { /* optional */ }
  let userTokenHex: string | undefined
  if (tokenChar) {
    const v = await tokenChar.readValue()
    userTokenHex = toHex(v).slice(0,16)
  }
  return { device, server, colorChar, tokenChar, userTokenHex }
}

export async function setBandColor(band: WebBand, color: ColorState) {
  if (!band.colorChar) throw new Error('COLOR_STATE characteristic not available')
  const buf = new Uint8Array([color])
  await band.colorChar.writeValue(buf)
}
