import React from 'react'
import { ColorState } from '../types'
import { colorHex, colorLabel } from '../utils/accessibility'

export function ColorPicker({
  value, onChange
}: { value: ColorState, onChange: (c: ColorState)=>void }) {
  const options: Array<{c: ColorState, label: string}> = [
    { c: ColorState.GREEN, label: colorLabel[ColorState.GREEN] },
    { c: ColorState.YELLOW, label: colorLabel[ColorState.YELLOW] },
    { c: ColorState.BLUE, label: colorLabel[ColorState.BLUE] },
    { c: ColorState.RED, label: colorLabel[ColorState.RED] },
    { c: ColorState.OFF, label: colorLabel[ColorState.OFF] },
  ]
  return (
    <div className="flex flex-wrap gap-3">
      {options.map(o => (
        <button
          key={o.c}
          className="btn"
          style={{ backgroundColor: colorHex[o.c], color: '#fff', opacity: value===o.c?1:0.8 }}
          aria-label={o.label}
          onClick={() => onChange(o.c)}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}
