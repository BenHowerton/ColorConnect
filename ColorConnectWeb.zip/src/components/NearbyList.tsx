import React from 'react'
import { useStore } from '../store'
import { ProfileCard } from './ProfileCard'

export function NearbyList({ onOpen }:{ onOpen: (p:any)=>void }) {
  const nearby = useStore(s => s.nearby)
  return (
    <div className="space-y-3">
      {nearby.length === 0 && (
        <div className="text-center text-gray-600 py-16">
          No GREEN neighbors nearby yet. Try opening Mock Mode or step into a common area.
        </div>
      )}
      {nearby.map(n => (
        <ProfileCard key={n.userToken} presence={n} onOpen={()=>onOpen(n)} />
      ))}
    </div>
  )
}
