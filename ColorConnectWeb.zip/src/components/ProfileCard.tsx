import React from 'react'
import { NearbyPresence } from '../types'

export function ProfileCard({ presence, onOpen }:{ presence: NearbyPresence, onOpen: ()=>void }){
  const u = presence.user
  const distance = presence.approxDistance <=3 ? 'Very near' : (presence.approxDistance<=9 ? 'Near' : 'In the room')
  return (
    <div className="card cursor-pointer" onClick={onOpen} role="button" aria-label={`Open ${u?.displayName ?? 'Neighbor'} profile`}>
      <div className="flex justify-between items-start gap-4">
        <div className="flex-1">
          <div className="text-lg font-semibold">{u?.displayName ?? 'Neighbor'}</div>
          {u?.inviteLine && <div className="text-sm text-gray-600 mt-1">{u.inviteLine}</div>}
          <div className="mt-2">
            {(u?.interests ?? []).slice(0,5).map(tag => (
              <span key={tag} className="chip">{tag}</span>
            ))}
          </div>
        </div>
        <div className="text-sm text-gray-500">{distance}</div>
      </div>
    </div>
  )
}
