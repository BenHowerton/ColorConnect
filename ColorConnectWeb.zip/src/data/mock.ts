import { ColorState, NearbyPresence, User } from '../types'

const INTERESTS = [
  'Walking','Coffee','Cards','Crafts','Pickleball','Gardening',
  'Book Club','Birdwatching','Puzzles','Volunteering','Yoga','Painting','Movies','Baking'
]

const NAMES = [
  { id: 'u1', name: 'Jane M.', invite: 'Walk mornings' },
  { id: 'u2', name: 'Luis R.', invite: 'Pickleball partner?' },
  { id: 'u3', name: 'Ava K.', invite: 'Game night buddy' },
  { id: 'u4', name: 'Sam T.', invite: 'Coffee & chat' },
  { id: 'u5', name: 'Nora L.', invite: 'Garden tips swap' },
  { id: 'u6', name: 'Ken P.', invite: 'Bridge on Tuesdays?' },
  { id: 'u7', name: 'Maya S.', invite: 'Morning yoga' },
  { id: 'u8', name: 'Ivy C.', invite: 'Movie matinee' },
  { id: 'u9', name: 'Owen D.', invite: 'Trail stroll' },
  { id: 'u10', name: 'Rita B.', invite: 'Crafts & tea' },
  { id: 'u11', name: 'Tom F.', invite: 'Chess match' },
  { id: 'u12', name: 'Ella N.', invite: 'Book chat' },
  { id: 'u13', name: 'Cara J.', invite: 'Photography walk' },
  { id: 'u14', name: 'Glen W.', invite: 'Dog park meetup' },
  { id: 'u15', name: 'Paul Q.', invite: 'Bocce ball?' },
  { id: 'u16', name: 'Nate V.', invite: 'Coffee tasting' },
  { id: 'u17', name: 'Zoe P.', invite: 'Art gallery trip' },
  { id: 'u18', name: 'Iris H.', invite: 'Knit & chat' },
  { id: 'u19', name: 'Leo R.', invite: 'Bike loop' },
  { id: 'u20', name: 'Ralph C.', invite: 'Pool at 3?' }
]

function pick<T>(arr: T[], n: number): T[] {
  const copy = [...arr]
  const out: T[] = []
  while (out.length < n && copy.length) {
    const i = Math.floor(Math.random()*copy.length)
    out.push(copy.splice(i,1)[0])
  }
  return out
}

export function seedUsers(): User[] {
  return NAMES.map((n, i) => ({
    id: n.id,
    displayName: n.name,
    inviteLine: n.invite,
    interests: pick(INTERESTS, 3),
    activities: pick(INTERESTS, 2),
    visibility: 'auto',
    lastColor: ((i % 10) < 4 ? ColorState.GREEN : (i % 10) < 7 ? ColorState.YELLOW : (i % 10) < 9 ? ColorState.BLUE : ColorState.RED)
  }))
}

export function simulateNearby(users: User[]): NearbyPresence[] {
  const results: NearbyPresence[] = []
  for (const u of users) {
    const active = Math.random() < 0.85
    if (!active) continue
    const rssi = Math.floor(Math.random()*30) - 90
    const meters = rssi > -60 ? 2 : rssi > -80 ? 8 : 15 + Math.random()*10
    const token = Math.random().toString(36).slice(2, 18).padEnd(16,'0').slice(0,16)
    results.push({
      userToken: token,
      approxDistance: Math.round(meters*10)/10,
      color: u.lastColor,
      user: u.lastColor === ColorState.GREEN ? u : undefined
    })
  }
  return results.filter(n => n.color === ColorState.GREEN).sort((a,b)=>a.approxDistance-b.approxDistance)
}
