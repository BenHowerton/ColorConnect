// Optional Supabase integration sketch (profile upsert + token lookup).
// To enable: set VITE_USE_MOCK=false and provide VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY in .env
import { createClient } from '@supabase/supabase-js'
import type { User } from '../types'

const url = import.meta.env.VITE_SUPABASE_URL
const key = import.meta.env.VITE_SUPABASE_ANON_KEY
export const supabase = (url && key) ? createClient(url, key) : null

export async function upsertProfile(u: User) {
  if (!supabase) return { error: 'Supabase not configured' }
  const { error } = await supabase.from('users').upsert({
    id: u.id,
    display_name: u.displayName,
    invite_line: u.inviteLine,
    interests: u.interests,
    activities: u.activities,
    visibility: u.visibility,
    last_color: u.lastColor
  })
  return { error }
}

export async function lookupByToken(token: string): Promise<User | null> {
  if (!supabase) return null
  const { data, error } = await supabase
    .rpc('get_user_by_token', { p_token: token }) // define a SQL function to enforce RLS
  if (error || !data) return null
  const u = data
  return {
    id: u.id,
    displayName: u.display_name,
    inviteLine: u.invite_line ?? undefined,
    interests: u.interests ?? [],
    activities: u.activities ?? [],
    visibility: (u.visibility ?? 'auto'),
    lastColor: u.last_color ?? 0
  }
}
