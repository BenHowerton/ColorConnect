import React, { useState } from 'react'
import { useStore } from '../store'
import { ColorState } from '../types'

export default function DirectorTools(){
  const [running, setRunning] = useState(false)
  const setDirectorMode = useStore(s => s.setDirectorMode)
  const setMyColor = useStore(s => s.setMyColor)

  const toggle = () => {
    const next = !running
    setRunning(next)
    setDirectorMode(next)
    if (next) setMyColor(ColorState.GREEN)
  }

  return (
    <div className="container py-8 space-y-4">
      <h1 className="text-3xl font-bold">Director Tools</h1>
      <p className="text-gray-600">Start a “Green Hour” to encourage friendly meetups. Your color turns GREEN and an etiquette screen is displayed.</p>
      <button className="btn" onClick={toggle}>{running ? 'Stop Green Hour' : 'Start Green Hour'}</button>
      <div className="card">
        <div className="font-semibold mb-2">Etiquette</div>
        <ul className="list-disc list-inside space-y-1">
          <li>✔ Say hello with your name</li>
          <li>● Keep it friendly and brief at first</li>
          <li>✚ Invite someone to join an activity</li>
          <li>— Respect RED and no-thanks</li>
        </ul>
      </div>
    </div>
  )
}
