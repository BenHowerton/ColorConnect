import React from 'react'

export default function Etiquette(){
  return (
    <div className="container py-8 space-y-2">
      <h1 className="text-3xl font-bold">Green Hour Etiquette</h1>
      <div>✔ Green = Please say hi</div>
      <div>● Yellow = Small talk ok</div>
      <div>✚ Blue = Looking for a buddy</div>
      <div>— Red = Quiet time</div>
      <p className="text-gray-600 mt-2">Be kind, introduce yourself, and respect boundaries.</p>
    </div>
  )
}
