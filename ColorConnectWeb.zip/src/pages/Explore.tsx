import React from 'react'

export default function Explore(){
  return (
    <div className="container py-8 space-y-4">
      <h1 className="text-3xl font-bold">Explore</h1>
      <p className="text-gray-600">Ideas & events to try together:</p>
      <div className="grid md:grid-cols-3 gap-4">
        <div className="card">
          <div className="font-semibold">Morning Walk Loop</div>
          <div className="text-gray-600">Meet at the lobby 8:30 AM. ~20 minutes.</div>
        </div>
        <div className="card">
          <div className="font-semibold">Puzzle & Tea</div>
          <div className="text-gray-600">Bring your favorite puzzle at 2 PM in the lounge.</div>
        </div>
        <div className="card">
          <div className="font-semibold">Pickleball 101</div>
          <div className="text-gray-600">Learn basics this Saturday 10 AM at the courts.</div>
        </div>
      </div>
    </div>
  )
}
