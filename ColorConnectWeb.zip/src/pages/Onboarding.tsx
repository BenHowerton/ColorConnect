import React from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { ColorState } from '../types'

const schema = z.object({
  displayName: z.string().min(1, 'Please enter your name'),
  inviteLine: z.string().optional(),
  interests: z.string().optional(),
  activities: z.string().optional(),
  consent: z.boolean().default(true)
})
type Form = z.infer<typeof schema>

export default function Onboarding(){
  const nav = useNavigate()
  const setMe = useStore(s => s.setMe)
  const { register, handleSubmit, formState: { errors } } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: { consent: true }
  })
  const onSubmit = (v: Form) => {
    setMe({
      displayName: v.displayName.trim(),
      inviteLine: v.inviteLine?.trim(),
      interests: (v.interests ?? '').split(',').map(s=>s.trim()).filter(Boolean),
      activities: (v.activities ?? '').split(',').map(s=>s.trim()).filter(Boolean),
      visibility: v.consent ? 'auto' : 'hidden',
      lastColor: ColorState.OFF
    })
    nav('/scan')
  }
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-4">Welcome to ColorConnect</h1>
      <p className="text-gray-600 mb-6">Create your simple profile. Your profile is only shown to neighbors when your color is GREEN (unless you choose to hide it).</p>
      <form className="space-y-4 max-w-xl" onSubmit={handleSubmit(onSubmit)}>
        <div>
          <label className="font-semibold">Display name</label>
          <input className="input mt-1" placeholder="Jane M." {...register('displayName')} />
          {errors.displayName && <p className="text-red-600 text-sm mt-1">{errors.displayName.message}</p>}
        </div>
        <div>
          <label className="font-semibold">Invite line (optional)</label>
          <input className="input mt-1" placeholder="Walk mornings" {...register('inviteLine')} />
        </div>
        <div>
          <label className="font-semibold">Interests (comma-separated)</label>
          <input className="input mt-1" placeholder="Walking, Coffee, Crafts" {...register('interests')} />
        </div>
        <div>
          <label className="font-semibold">Activities (comma-separated)</label>
          <input className="input mt-1" placeholder="Picnic, Game Night" {...register('activities')} />
        </div>
        <div className="flex items-center gap-3">
          <input type="checkbox" {...register('consent')} />
          <span>Share my profile when I’m GREEN</span>
        </div>
        <button className="btn" type="submit">Continue</button>
      </form>
    </div>
  )
}
