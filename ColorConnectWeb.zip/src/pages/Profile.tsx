import React from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import type { NearbyPresence } from '../types'

export default function Profile(){
  const nav = useNavigate()
  const { state } = useLocation()
  const params = useParams()
  const presence = state as (NearbyPresence | undefined)

  if (!presence) {
    return (
      <div className="container py-8">
        <button className="btn" onClick={()=>nav(-1)}>Back</button>
        <div className="mt-6">No profile.</div>
      </div>
    )
  }

  const u = presence.user

  return (
    <div className="container py-8 space-y-4">
      <button className="btn" onClick={()=>nav(-1)}>Back</button>
      <h1 className="text-3xl font-bold">{u?.displayName ?? params['*'] ?? 'Neighbor'}</h1>
      {u?.inviteLine && <p className="text-lg text-gray-600">{u.inviteLine}</p>}
      <div>
        <h2 className="font-semibold">Interests</h2>
        <p className="text-gray-700">{(u?.interests ?? []).join(', ') || '—'}</p>
      </div>
      <div>
        <h2 className="font-semibold">Activities</h2>
        <p className="text-gray-700">{(u?.activities ?? []).join(', ') || '—'}</p>
      </div>
      <div className="card">
        <div className="font-semibold mb-2">How it works</div>
        <p className="text-gray-600">Profiles are visible only when a neighbor’s color is GREEN (Please say hi). Be kind, introduce yourself, and enjoy the conversation!</p>
      </div>
    </div>
  )
}
