import React from 'react'
import { useStore } from '../store'

export default function ProfileEditor(){
  const me = useStore(s => s.me)
  const setMe = useStore(s => s.setMe)

  return (
    <div className="container py-8 space-y-4">
      <h1 className="text-3xl font-bold">My Profile</h1>
      <div>
        <label className="font-semibold">Display name</label>
        <input className="input mt-1" value={me?.displayName ?? ''} onChange={e=>setMe({ displayName: e.target.value })} />
      </div>
      <div>
        <label className="font-semibold">Invite line</label>
        <input className="input mt-1" value={me?.inviteLine ?? ''} onChange={e=>setMe({ inviteLine: e.target.value })} />
      </div>
      <div>
        <label className="font-semibold">Interests (comma-separated)</label>
        <input className="input mt-1" value={(me?.interests ?? []).join(', ')} onChange={e=>setMe({ interests: e.target.value.split(',').map(s=>s.trim()).filter(Boolean) })} />
      </div>
      <div>
        <label className="font-semibold">Activities (comma-separated)</label>
        <input className="input mt-1" value={(me?.activities ?? []).join(', ')} onChange={e=>setMe({ activities: e.target.value.split(',').map(s=>s.trim()).filter(Boolean) })} />
      </div>
      <button className="btn">Save</button>
    </div>
  )
}
