import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { ColorState } from '../types'
import { ColorPicker } from '../components/ColorPicker'
import { NearbyList } from '../components/NearbyList'
import { seedUsers, simulateNearby } from '../data/mock'
import { connectBand, setBandColor, WebBand } from '../ble/webBle'

export default function Scan(){
  const nav = useNavigate()
  const [users] = useState(()=>seedUsers())
  const [band, setBand] = useState<WebBand | null>(null)
  const myColor = useStore(s => s.myColor)
  const setMyColor = useStore(s => s.setMyColor)
  const useMock = useStore(s => s.useMock)
  const setNearby = useStore(s => s.setNearby)

  useEffect(() => {
    if (useMock) {
      const tick = () => setNearby(simulateNearby(users))
      const id = setInterval(tick, 5000)
      tick()
      return ()=>clearInterval(id)
    } else {
      setNearby([])
    }
  }, [useMock, setNearby, users])

  const onChangeColor = async (c: ColorState) => {
    setMyColor(c)
    if (band) {
      try { await setBandColor(band, c) } catch(e){ console.error(e) }
    }
  }

  const onConnect = async () => {
    try {
      const b = await connectBand()
      setBand(b)
      // set current color on connect
      await setBandColor(b, myColor)
      alert(`Band connected${b.userTokenHex ? ' (token '+b.userTokenHex+')' : ''}`)
    } catch (e:any) {
      alert(e?.message ?? 'Failed to connect')
    }
  }

  return (
    <div className="container py-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Scan</h1>
        <p className="text-gray-600 mb-4">Use your color to show how open you are to conversation. GREEN shows your profile to nearby neighbors.</p>
        <div className="flex flex-wrap items-center gap-3">
          <ColorPicker value={myColor} onChange={onChangeColor} />
          <button className="btn" onClick={()=>nav('/etiquette')}>See etiquette</button>
          <button className="btn" onClick={onConnect}>Connect my band (Web Bluetooth)</button>
        </div>
      </div>
      <NearbyList onOpen={(p)=> nav(`/profile/${encodeURIComponent(p.user?.displayName ?? 'neighbor')}`, { state: p })} />
    </div>
  )
}
