import React from 'react'
import { useStore } from '../store'

export default function Settings(){
  const useMock = useStore(s => s.useMock)
  const setUseMock = useStore(s => s.setUseMock)
  const me = useStore(s => s.me)
  const setMe = useStore(s => s.setMe)

  return (
    <div className="container py-8 space-y-6">
      <h1 className="text-3xl font-bold">Settings</h1>
      <div className="card flex items-center justify-between">
        <div>Mock Mode (no hardware)</div>
        <input type="checkbox" checked={useMock} onChange={e=>setUseMock(e.target.checked)} />
      </div>
      <div className="card flex items-center justify-between">
        <div>Hide my profile unless GREEN</div>
        <input type="checkbox" checked={me?.visibility === 'hidden'} onChange={e=>setMe({ visibility: e.target.checked ? 'hidden' : 'auto' })} />
      </div>
    </div>
  )
}
