import { create } from 'zustand'
import { ColorState, NearbyPresence, User } from './types'

type State = {
  me?: User
  setMe: (u: Partial<User>) => void

  myColor: ColorState
  setMyColor: (c: ColorState) => void

  useMock: boolean
  setUseMock: (v: boolean) => void

  nearby: NearbyPresence[]
  setNearby: (list: NearbyPresence[]) => void

  directorMode: boolean
  setDirectorMode: (v: boolean) => void
}

export const useStore = create<State>((set) => ({
  me: undefined,
  setMe: (u) => set((s) => ({ me: { ...(s.me ?? defaultUser()), ...u } })),

  myColor: ColorState.OFF,
  setMyColor: (c) => set({ myColor: c }),

  useMock: (import.meta.env.VITE_USE_MOCK ?? 'true') === 'true',
  setUseMock: (v) => set({ useMock: v }),

  nearby: [],
  setNearby: (list) => set({ nearby: list }),

  directorMode: false,
  setDirectorMode: (v) => set({ directorMode: v })
}))

function defaultUser(): User {
  return {
    id: 'me',
    displayName: '',
    inviteLine: '',
    interests: [],
    activities: [],
    visibility: 'auto',
    lastColor: ColorState.OFF
  }
}
