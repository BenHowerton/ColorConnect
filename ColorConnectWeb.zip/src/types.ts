export enum ColorState {
  OFF = 0,
  GREEN = 1,
  YELLOW = 2,
  BLUE = 3,
  RED = 4,
}

export type User = {
  id: string;
  displayName: string;
  inviteLine?: string;
  interests: string[];
  activities: string[];
  visibility: 'auto' | 'hidden';
  lastColor: ColorState;
};

export type NearbyPresence = {
  userToken: string;
  approxDistance: number;
  color: ColorState;
  user?: User;
};

export const SERVICE_UUID = 'b59a0001-13f0-4c2a-b4ce-7d6fddc0aa01';
export const CHAR_COLOR_STATE = 'b59a0002-13f0-4c2a-b4ce-7d6fddc0aa01';
export const CHAR_USER_TOKEN = 'b59a0003-13f0-4c2a-b4ce-7d6fddc0aa01';
