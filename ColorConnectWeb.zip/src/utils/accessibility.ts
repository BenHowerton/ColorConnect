import { ColorState } from '../types'

export const colorLabel: Record<ColorState, string> = {
  [ColorState.OFF]: 'Off',
  [ColorState.GREEN]: 'Green — Please say hi',
  [ColorState.YELLOW]: 'Yellow — Small talk ok',
  [ColorState.BLUE]: 'Blue — Looking for a buddy',
  [ColorState.RED]: 'Red — Quiet time',
}

export const colorHex: Record<ColorState, string> = {
  [ColorState.OFF]: '#95a5a6',
  [ColorState.GREEN]: '#2ecc71',
  [ColorState.YELLOW]: '#f1c40f',
  [ColorState.BLUE]: '#3498db',
  [ColorState.RED]: '#e74c3c',
}
