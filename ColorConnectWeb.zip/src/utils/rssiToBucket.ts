export type DistanceBucket = 'Very near' | 'Near' | 'In the room'

export function rssiToBucket(rssi?: number): DistanceBucket {
  if (rssi == null) return 'In the room'
  if (rssi > -60) return 'Very near'
  if (rssi > -80) return 'Near'
  return 'In the room'
}
